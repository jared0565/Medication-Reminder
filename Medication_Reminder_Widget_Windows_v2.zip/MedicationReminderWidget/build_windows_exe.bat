@echo off
title Build Medication Reminder EXE
cd /d "%~dp0"
py -m pip install pyinstaller
pyinstaller --noconfirm --clean --onefile --windowed ^
  --name MedicationReminder ^
  --icon medication_icon.ico ^
  medication_reminder.py
echo.
echo Build complete. See the dist folder.
pause
