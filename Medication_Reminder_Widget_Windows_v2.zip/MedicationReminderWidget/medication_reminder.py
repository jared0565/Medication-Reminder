
from __future__ import annotations

import json
import os
import sys
import threading
import time
import winsound
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

from PIL import Image
import pystray


APP_NAME = "Medication Reminder"
CHECK_INTERVAL_SECONDS = 15
DEFAULT_SNOOZE_MINUTES = 10


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


BASE_DIR = app_dir()
CONFIG_PATH = BASE_DIR / "medication_schedule.json"
LOG_PATH = BASE_DIR / "medication_log.csv"
ICON_PATH = BASE_DIR / "medication_icon.ico"


@dataclass
class DueEvent:
    event_id: str
    label: str
    time_text: str
    medicines: list[str]
    instructions: str


class MedicationReminderApp:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title(APP_NAME)
        self.root.geometry("620x490")
        self.root.minsize(560, 420)
        self.root.protocol("WM_DELETE_WINDOW", self.hide_to_tray)

        self.config_data = self.load_config()
        self.alerted_keys: set[str] = set()
        self.snoozed_until: dict[str, datetime] = {}
        self.active_popup: tk.Toplevel | None = None
        self.tray_icon: pystray.Icon | None = None
        self.running = True

        self.build_main_window()
        self.start_tray_icon()
        self.root.after(1000, self.check_schedule)

    def load_config(self) -> dict:
        try:
            with CONFIG_PATH.open("r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:
            messagebox.showerror(
                APP_NAME,
                f"Could not read medication_schedule.json.\n\n{exc}"
            )
            raise

    def save_config(self) -> None:
        with CONFIG_PATH.open("w", encoding="utf-8") as f:
            json.dump(self.config_data, f, indent=2, ensure_ascii=False)

    def build_main_window(self) -> None:
        outer = ttk.Frame(self.root, padding=18)
        outer.pack(fill="both", expand=True)

        ttk.Label(
            outer,
            text="Medication Reminder",
            font=("Segoe UI", 20, "bold")
        ).pack(anchor="w")

        ttk.Label(
            outer,
            text="The application can stay minimized in the Windows system tray. "
                 "A reminder window and sound appear when medication is due.",
            wraplength=560
        ).pack(anchor="w", pady=(4, 14))

        self.status_var = tk.StringVar(value="Running")
        status = ttk.Label(
            outer,
            textvariable=self.status_var,
            font=("Segoe UI", 10, "bold")
        )
        status.pack(anchor="w", pady=(0, 8))

        columns = ("time", "label", "medicines")
        self.tree = ttk.Treeview(outer, columns=columns, show="headings", height=12)
        self.tree.heading("time", text="Time")
        self.tree.heading("label", text="Reminder")
        self.tree.heading("medicines", text="Medication / nutrition")
        self.tree.column("time", width=80, anchor="center")
        self.tree.column("label", width=145)
        self.tree.column("medicines", width=330)
        self.tree.pack(fill="both", expand=True)

        button_bar = ttk.Frame(outer)
        button_bar.pack(fill="x", pady=(14, 0))

        ttk.Button(
            button_bar, text="Test reminder", command=self.test_reminder
        ).pack(side="left")

        ttk.Button(
            button_bar, text="Edit schedule", command=self.open_schedule_editor
        ).pack(side="left", padx=8)

        ttk.Button(
            button_bar, text="Minimize to tray", command=self.hide_to_tray
        ).pack(side="right")

        self.refresh_schedule_table()
        self.update_next_due_text()

    def refresh_schedule_table(self) -> None:
        for row in self.tree.get_children():
            self.tree.delete(row)

        for event in sorted(
            self.config_data.get("events", []),
            key=lambda x: x.get("time", "99:99")
        ):
            if not event.get("enabled", True):
                continue
            medicines = "; ".join(event.get("medicines", []))
            self.tree.insert(
                "", "end",
                values=(event.get("time", ""), event.get("label", ""), medicines)
            )

    def update_next_due_text(self) -> None:
        now = datetime.now()
        due_items: list[tuple[datetime, str]] = []

        for offset in range(0, 8):
            day = now + timedelta(days=offset)
            weekday = day.strftime("%a").lower()[:3]

            for event in self.config_data.get("events", []):
                if not self.event_active(event, day.date(), weekday):
                    continue

                hour, minute = [int(v) for v in event["time"].split(":")]
                candidate = day.replace(
                    hour=hour, minute=minute, second=0, microsecond=0
                )
                if candidate >= now:
                    due_items.append((candidate, event.get("label", "Medication")))

        if due_items:
            when, label = min(due_items, key=lambda x: x[0])
            self.status_var.set(
                f"Running • Next: {label} at {when.strftime('%a %d %b, %H:%M')}"
            )
        else:
            self.status_var.set("Running • No active reminders found")

        self.root.after(30_000, self.update_next_due_text)

    def event_active(self, event: dict, day, weekday: str) -> bool:
        if not event.get("enabled", True):
            return False

        allowed_days = event.get("days", ["daily"])
        if "daily" not in allowed_days and weekday not in allowed_days:
            return False

        start_date = event.get("start_date")
        end_date = event.get("end_date")

        if start_date and day < datetime.strptime(start_date, "%Y-%m-%d").date():
            return False
        if end_date and day > datetime.strptime(end_date, "%Y-%m-%d").date():
            return False

        return True

    def check_schedule(self) -> None:
        if not self.running:
            return

        now = datetime.now()
        date_key = now.strftime("%Y-%m-%d")
        weekday = now.strftime("%a").lower()[:3]

        # Keep only today's alert keys.
        self.alerted_keys = {
            key for key in self.alerted_keys if key.startswith(date_key)
        }

        for event in self.config_data.get("events", []):
            if not self.event_active(event, now.date(), weekday):
                continue

            event_time = event.get("time", "")
            key = f"{date_key}|{event.get('id')}|{event_time}"

            snooze_until = self.snoozed_until.get(key)
            if snooze_until and now >= snooze_until and key not in self.alerted_keys:
                self.show_due_popup(self.to_due_event(event), key)
                break

            if now.strftime("%H:%M") == event_time and key not in self.alerted_keys:
                self.show_due_popup(self.to_due_event(event), key)
                break

        self.root.after(CHECK_INTERVAL_SECONDS * 1000, self.check_schedule)

    def to_due_event(self, event: dict) -> DueEvent:
        return DueEvent(
            event_id=event.get("id", ""),
            label=event.get("label", "Medication due"),
            time_text=event.get("time", ""),
            medicines=event.get("medicines", []),
            instructions=event.get("instructions", "")
        )

    def play_alert_sound(self) -> None:
        def worker() -> None:
            try:
                for _ in range(3):
                    winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                    time.sleep(0.7)
            except Exception:
                pass

        threading.Thread(target=worker, daemon=True).start()

    def show_due_popup(self, event: DueEvent, key: str) -> None:
        self.alerted_keys.add(key)
        self.snoozed_until.pop(key, None)
        self.play_alert_sound()

        if self.active_popup and self.active_popup.winfo_exists():
            self.active_popup.destroy()

        popup = tk.Toplevel(self.root)
        self.active_popup = popup
        popup.title("Medication due")
        popup.geometry("520x390")
        popup.resizable(False, False)
        popup.attributes("-topmost", True)
        popup.lift()
        popup.focus_force()
        popup.protocol("WM_DELETE_WINDOW", lambda: self.snooze_event(key, popup))

        frame = ttk.Frame(popup, padding=22)
        frame.pack(fill="both", expand=True)

        ttk.Label(
            frame,
            text=f"MEDICATION DUE • {event.time_text}",
            font=("Segoe UI", 13, "bold")
        ).pack(anchor="center", pady=(0, 8))

        ttk.Label(
            frame,
            text=event.label,
            font=("Segoe UI", 19, "bold")
        ).pack(anchor="center", pady=(0, 14))

        meds_box = tk.Text(
            frame,
            height=max(5, len(event.medicines) + 1),
            width=48,
            wrap="word",
            font=("Segoe UI", 13),
            relief="solid",
            borderwidth=1,
            padx=12,
            pady=10
        )
        meds_box.pack(fill="x")
        meds_box.insert("1.0", "\n".join(f"• {m}" for m in event.medicines))
        meds_box.configure(state="disabled")

        if event.instructions:
            ttk.Label(
                frame,
                text=event.instructions,
                wraplength=460,
                justify="left",
                font=("Segoe UI", 10)
            ).pack(anchor="w", pady=(14, 16))

        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", side="bottom")

        ttk.Button(
            buttons,
            text="Taken",
            command=lambda: self.mark_taken(event, key, popup)
        ).pack(side="left", expand=True, fill="x", padx=(0, 6))

        ttk.Button(
            buttons,
            text=f"Snooze {DEFAULT_SNOOZE_MINUTES} min",
            command=lambda: self.snooze_event(key, popup)
        ).pack(side="left", expand=True, fill="x", padx=(6, 0))

        popup.bell()

    def mark_taken(self, event: DueEvent, key: str, popup: tk.Toplevel) -> None:
        self.write_log("TAKEN", event)
        self.snoozed_until.pop(key, None)
        popup.destroy()

    def snooze_event(self, key: str, popup: tk.Toplevel) -> None:
        self.alerted_keys.discard(key)
        self.snoozed_until[key] = datetime.now() + timedelta(
            minutes=DEFAULT_SNOOZE_MINUTES
        )
        popup.destroy()

    def write_log(self, status: str, event: DueEvent) -> None:
        new_file = not LOG_PATH.exists()
        with LOG_PATH.open("a", encoding="utf-8", newline="") as f:
            if new_file:
                f.write("timestamp,status,event_id,label,scheduled_time,items\n")
            items = " | ".join(event.medicines).replace('"', '""')
            label = event.label.replace('"', '""')
            f.write(
                f'{datetime.now().isoformat(timespec="seconds")},{status},'
                f'{event.event_id},"{label}",{event.time_text},"{items}"\n'
            )

    def test_reminder(self) -> None:
        sample = DueEvent(
            event_id="test",
            label="Test reminder",
            time_text=datetime.now().strftime("%H:%M"),
            medicines=["This is a test alert", "No medication should be taken"],
            instructions="Use this button to confirm that the sound and reminder window work."
        )
        self.show_due_popup(sample, f"test-{time.time()}")

    def open_schedule_editor(self) -> None:
        editor = tk.Toplevel(self.root)
        editor.title("Edit reminder schedule")
        editor.geometry("760x520")
        editor.transient(self.root)

        container = ttk.Frame(editor, padding=14)
        container.pack(fill="both", expand=True)

        columns = ("enabled", "time", "label", "medicines")
        tree = ttk.Treeview(container, columns=columns, show="headings", height=15)
        tree.heading("enabled", text="On")
        tree.heading("time", text="Time")
        tree.heading("label", text="Label")
        tree.heading("medicines", text="Items")
        tree.column("enabled", width=45, anchor="center")
        tree.column("time", width=70, anchor="center")
        tree.column("label", width=160)
        tree.column("medicines", width=410)
        tree.pack(fill="both", expand=True)

        def populate() -> None:
            for item in tree.get_children():
                tree.delete(item)
            for idx, event in enumerate(self.config_data.get("events", [])):
                tree.insert(
                    "", "end", iid=str(idx),
                    values=(
                        "Yes" if event.get("enabled", True) else "No",
                        event.get("time", ""),
                        event.get("label", ""),
                        "; ".join(event.get("medicines", []))
                    )
                )

        def toggle() -> None:
            selected = tree.selection()
            if not selected:
                return
            idx = int(selected[0])
            event = self.config_data["events"][idx]
            event["enabled"] = not event.get("enabled", True)
            self.save_config()
            populate()
            self.refresh_schedule_table()

        def edit_selected() -> None:
            selected = tree.selection()
            if not selected:
                messagebox.showinfo(APP_NAME, "Select a reminder first.")
                return
            idx = int(selected[0])
            event = self.config_data["events"][idx]
            self.edit_event_dialog(editor, event, populate)

        buttons = ttk.Frame(container)
        buttons.pack(fill="x", pady=(12, 0))
        ttk.Button(buttons, text="Enable / disable", command=toggle).pack(side="left")
        ttk.Button(buttons, text="Edit selected", command=edit_selected).pack(side="left", padx=8)
        ttk.Button(buttons, text="Close", command=editor.destroy).pack(side="right")

        populate()

    def edit_event_dialog(self, parent: tk.Toplevel, event: dict, refresh_callback) -> None:
        dialog = tk.Toplevel(parent)
        dialog.title("Edit reminder")
        dialog.geometry("570x440")
        dialog.transient(parent)
        dialog.grab_set()

        form = ttk.Frame(dialog, padding=18)
        form.pack(fill="both", expand=True)

        time_var = tk.StringVar(value=event.get("time", ""))
        label_var = tk.StringVar(value=event.get("label", ""))
        enabled_var = tk.BooleanVar(value=event.get("enabled", True))
        days_var = tk.StringVar(value=", ".join(event.get("days", ["daily"])))
        end_var = tk.StringVar(value=event.get("end_date") or "")

        ttk.Label(form, text="Time (24-hour HH:MM)").pack(anchor="w")
        ttk.Entry(form, textvariable=time_var).pack(fill="x", pady=(2, 8))

        ttk.Label(form, text="Reminder label").pack(anchor="w")
        ttk.Entry(form, textvariable=label_var).pack(fill="x", pady=(2, 8))

        ttk.Label(form, text="Medication/items, one per line").pack(anchor="w")
        medicines_text = tk.Text(form, height=7, wrap="word")
        medicines_text.pack(fill="x", pady=(2, 8))
        medicines_text.insert("1.0", "\n".join(event.get("medicines", [])))

        ttk.Label(form, text="Days: daily or mon,tue,wed...").pack(anchor="w")
        ttk.Entry(form, textvariable=days_var).pack(fill="x", pady=(2, 8))

        ttk.Label(form, text="End date (optional, YYYY-MM-DD)").pack(anchor="w")
        ttk.Entry(form, textvariable=end_var).pack(fill="x", pady=(2, 8))

        ttk.Checkbutton(form, text="Reminder enabled", variable=enabled_var).pack(anchor="w")

        def save() -> None:
            try:
                datetime.strptime(time_var.get().strip(), "%H:%M")
                if end_var.get().strip():
                    datetime.strptime(end_var.get().strip(), "%Y-%m-%d")
            except ValueError:
                messagebox.showerror(
                    APP_NAME,
                    "Use HH:MM for time and YYYY-MM-DD for the optional end date."
                )
                return

            event["time"] = time_var.get().strip()
            event["label"] = label_var.get().strip()
            event["medicines"] = [
                x.strip() for x in medicines_text.get("1.0", "end").splitlines()
                if x.strip()
            ]
            event["days"] = [
                x.strip().lower() for x in days_var.get().split(",") if x.strip()
            ] or ["daily"]
            event["end_date"] = end_var.get().strip() or None
            event["enabled"] = enabled_var.get()

            self.save_config()
            self.refresh_schedule_table()
            refresh_callback()
            dialog.destroy()

        ttk.Button(form, text="Save changes", command=save).pack(anchor="e", pady=(12, 0))

    def hide_to_tray(self) -> None:
        self.root.withdraw()

    def show_window(self) -> None:
        self.root.after(0, self._show_window_main_thread)

    def _show_window_main_thread(self) -> None:
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()

    def start_tray_icon(self) -> None:
        image = Image.open(ICON_PATH)
        menu = pystray.Menu(
            pystray.MenuItem("Open medication reminder", lambda: self.show_window(), default=True),
            pystray.MenuItem("Test reminder", lambda: self.root.after(0, self.test_reminder)),
            pystray.MenuItem("Exit", lambda: self.root.after(0, self.quit_app))
        )
        self.tray_icon = pystray.Icon("MedicationReminder", image, APP_NAME, menu)
        threading.Thread(target=self.tray_icon.run, daemon=True).start()

    def quit_app(self) -> None:
        self.running = False
        if self.tray_icon:
            self.tray_icon.stop()
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


if __name__ == "__main__":
    MedicationReminderApp().run()
