
# Medication Reminder Widget for Windows

A lightweight Windows tray application that accompanies the printed medication plan.

## Main features

- Runs in the Windows system tray
- Checks the medication schedule automatically
- Plays an audible Windows alert when medication is due
- Displays an always-on-top reminder window
- Shows the medication names and timing instructions
- Includes **Taken** and **Snooze 10 min** buttons
- Saves completed reminders to `medication_log.csv`
- Allows reminders to be enabled, disabled, or edited
- Includes a test-reminder button

## Important clinical note

This program is an organisational aid, not a medical device. The Royal Free transplant team's latest instructions always take priority. Check the schedule whenever a medicine is started, stopped, or changed.

The temporary cefalexin reminders are enabled by default. Disable them in **Edit schedule** when the prescribed course is complete.

## Quick start

1. Install Python 3.11 or newer for Windows.
2. Double-click `install_dependencies.bat`.
3. Double-click `run_medication_reminder.bat`.
4. In the application, select **Test reminder**.
5. Select **Minimize to tray**.

The app must remain running for reminders to appear.

## Build a single Windows EXE

1. Run `install_dependencies.bat`.
2. Run `build_windows_exe.bat`.
3. The executable will be created inside the `dist` folder.

Copy these files into the same folder as the EXE:

- `medication_schedule.json`
- `medication_icon.ico`

## Start automatically with Windows

After confirming the program works:

1. Press `Win + R`
2. Enter `shell:startup`
3. Place a shortcut to `run_medication_reminder.bat` or the built EXE in that folder.

## Editing the schedule

Open the main window from the system tray and select **Edit schedule**.

- Time uses 24-hour format, such as `07:00`
- Days can be `daily` or a comma-separated list such as `mon,tue,wed`
- An optional end date can automatically stop temporary reminders

## Files

- `medication_reminder.py` — application
- `medication_schedule.json` — editable schedule
- `medication_log.csv` — created after the first completed reminder
- `medication_icon.ico` — tray/application icon
