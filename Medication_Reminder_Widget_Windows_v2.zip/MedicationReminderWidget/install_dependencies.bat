@echo off
title Install Medication Reminder
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
echo.
echo Installation complete.
pause
